<?php
/**
 * Plugin Name:       Pak-Munshi Pro
 * Plugin URI:        https://pakmunshi.com
 * Description:       Hierarchical Role-Based Multi-Tenant SaaS core system for PakMunshi Pro.
 * Version:           1.0.0
 * Author:            Sami Khan - SQ Tech
 * Author URI:        #
 * Text Domain:       pak-munshi-saas
 * License:           GPL v2 or later
 *
 * Designed and Developed by Sami Khan - SQ Tech
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Global Constants
if ( ! defined( 'PAKMUNSHI_SAAS_VERSION' ) ) {
    define( 'PAKMUNSHI_SAAS_VERSION', '1.0.0' );
}
if ( ! defined( 'PAKMUNSHI_BRANDING' ) ) {
    define( 'PAKMUNSHI_BRANDING', 'Designed and Developed by Sami Khan - SQ Tech' );
}
if ( ! defined( 'PAKMUNSHI_DASHBOARD_SLUG' ) ) {
    define( 'PAKMUNSHI_DASHBOARD_SLUG', 'dashboard' );
}

/**
 * Register Activation Hooks
 */
register_activation_hook( __FILE__, 'pakmunshi_saas_activate' );
if ( ! function_exists( 'pakmunshi_saas_activate' ) ) {
    function pakmunshi_saas_activate() {
        pakmunshi_saas_create_tables();
        pakmunshi_create_dashboard_page_fallback();
        flush_rewrite_rules();
    }
}

/**
 * Register Deactivation Hooks
 */
register_deactivation_hook( __FILE__, 'pakmunshi_saas_deactivate' );
if ( ! function_exists( 'pakmunshi_saas_deactivate' ) ) {
    function pakmunshi_saas_deactivate() {
        flush_rewrite_rules();
    }
}

/**
 * Phase 1: Database Tables Creation Engine
 * Generates custom MySQL tables with $wpdb and dbDelta
 */
if ( ! function_exists( 'pakmunshi_saas_create_tables' ) ) {
    function pakmunshi_saas_create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table_prefix = $wpdb->prefix;
        $sql = array();

        // 1. SaaS Tenants (Business Accounts / Landlords)
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_tenants (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_uuid varchar(64) NOT NULL,
            company_name varchar(200) NOT NULL,
            slug varchar(100) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            subscription_plan varchar(50) NOT NULL DEFAULT 'free',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY tenant_uuid (tenant_uuid),
            UNIQUE KEY slug (slug)
        ) $charset_collate;";

        // 2. SaaS Tenant Users (WP User Link with Hierarchical Roles)
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_users (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            wp_user_id bigint(20) unsigned NOT NULL,
            role varchar(50) NOT NULL DEFAULT 'tenant_staff',
            status varchar(50) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY wp_user_tenant (wp_user_id, tenant_id),
            KEY tenant_id (tenant_id)
        ) $charset_collate;";

        // 3. Tenant-aware Properties
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_properties (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            name varchar(200) NOT NULL,
            address text NOT NULL,
            type varchar(50) NOT NULL DEFAULT 'Residential',
            total_floors int(4) NOT NULL DEFAULT 1,
            description text,
            status varchar(20) NOT NULL DEFAULT 'Active',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tenant_id (tenant_id)
        ) $charset_collate;";

        // 4. Tenant-aware Units
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_units (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            property_id bigint(20) unsigned NOT NULL,
            unit_number varchar(50) NOT NULL,
            floor int(4) NOT NULL DEFAULT 0,
            unit_type varchar(50) NOT NULL DEFAULT 'Flat',
            area_sqft decimal(10,2) DEFAULT NULL,
            rent_amount decimal(12,2) NOT NULL DEFAULT 0.00,
            maintenance_fee decimal(12,2) NOT NULL DEFAULT 0.00,
            water_charges decimal(12,2) NOT NULL DEFAULT 500.00,
            status varchar(20) NOT NULL DEFAULT 'Vacant',
            notes text,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tenant_id (tenant_id),
            KEY property_id (property_id)
        ) $charset_collate;";

        // 5. Tenant-aware Rental Tenants (Occupants renting units)
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_rental_tenants (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            unit_id bigint(20) unsigned NOT NULL,
            full_name varchar(200) NOT NULL,
            father_name varchar(200) DEFAULT NULL,
            cnic varchar(20) DEFAULT NULL,
            phone varchar(20) NOT NULL,
            whatsapp varchar(20) DEFAULT NULL,
            email varchar(100) DEFAULT NULL,
            permanent_address text,
            occupation varchar(100) DEFAULT NULL,
            family_members int(4) NOT NULL DEFAULT 1,
            security_deposit decimal(12,2) NOT NULL DEFAULT 0.00,
            agreement_start date NOT NULL,
            agreement_end date DEFAULT NULL,
            advance_months int(2) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'Active',
            notes text,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tenant_id (tenant_id),
            KEY unit_id (unit_id)
        ) $charset_collate;";

        // 6. Tenant-aware Invoices
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_invoices (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            rental_tenant_id bigint(20) unsigned NOT NULL,
            invoice_number varchar(50) NOT NULL,
            billing_month varchar(7) NOT NULL,
            due_date date NOT NULL,
            rent_amount decimal(12,2) NOT NULL DEFAULT 0.00,
            electricity_units decimal(10,2) NOT NULL DEFAULT 0.00,
            electricity_rate decimal(10,2) NOT NULL DEFAULT 25.00,
            electricity_amount decimal(12,2) NOT NULL DEFAULT 0.00,
            water_charges decimal(12,2) NOT NULL DEFAULT 0.00,
            maintenance_fee decimal(12,2) NOT NULL DEFAULT 0.00,
            other_charges decimal(12,2) NOT NULL DEFAULT 0.00,
            other_desc varchar(200) DEFAULT NULL,
            arrears decimal(12,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(12,2) NOT NULL DEFAULT 0.00,
            paid_amount decimal(12,2) NOT NULL DEFAULT 0.00,
            balance decimal(12,2) NOT NULL DEFAULT 0.00,
            status varchar(20) NOT NULL DEFAULT 'Unpaid',
            notes text,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY invoice_number (invoice_number),
            KEY tenant_id (tenant_id),
            KEY rental_tenant_id (rental_tenant_id),
            KEY billing_month (billing_month)
        ) $charset_collate;";

        // 7. Tenant-aware Payments
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_payments (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            invoice_id bigint(20) unsigned NOT NULL,
            receipt_number varchar(50) NOT NULL,
            amount decimal(12,2) NOT NULL,
            paid_date date NOT NULL,
            payment_method varchar(50) NOT NULL DEFAULT 'Cash',
            reference_no varchar(100) DEFAULT NULL,
            bank_name varchar(100) DEFAULT NULL,
            notes text,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tenant_id (tenant_id),
            KEY invoice_id (invoice_id)
        ) $charset_collate;";

        // 8. Tenant-aware Documents
        $sql[] = "CREATE TABLE {$table_prefix}pakmunshi_documents (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tenant_id bigint(20) unsigned NOT NULL,
            rental_tenant_id bigint(20) unsigned NOT NULL,
            doc_type varchar(50) NOT NULL DEFAULT 'CNIC',
            file_name varchar(255) NOT NULL,
            file_url text NOT NULL,
            uploaded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tenant_id (tenant_id),
            KEY rental_tenant_id (rental_tenant_id)
        ) $charset_collate;";

        foreach ( $sql as $query ) {
            dbDelta( $query );
        }

        update_option( 'pakmunshi_saas_db_version', PAKMUNSHI_SAAS_VERSION );
    }
}

/**
 * Creates the dashboard page if it does not exist
 */
if ( ! function_exists( 'pakmunshi_create_dashboard_page_fallback' ) ) {
    function pakmunshi_create_dashboard_page_fallback() {
        $existing = get_page_by_path( PAKMUNSHI_DASHBOARD_SLUG );
        if ( $existing ) {
            return;
        }
        wp_insert_post( array(
            'post_title'     => 'Dashboard',
            'post_name'      => PAKMUNSHI_DASHBOARD_SLUG,
            'post_content'   => '<!-- PakMunshi Standalone App Shell -->',
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'post_author'    => 1,
            'comment_status' => 'closed',
        ) );
    }
}

/**
 * Theme Synchronization: Intercepts request routing for the /dashboard slug,
 * completely bypassing Astra Pro headers/footers.
 */
add_action( 'template_redirect', 'pakmunshi_dashboard_template_redirect' );
if ( ! function_exists( 'pakmunshi_dashboard_template_redirect' ) ) {
    function pakmunshi_dashboard_template_redirect() {
        if ( ! is_page( PAKMUNSHI_DASHBOARD_SLUG ) ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            wp_redirect( wp_login_url( get_permalink() ) );
            exit;
        }

        // Bypass theme templates (Astra Pro headers/footers)
        status_header( 200 );
        
        // Inject the standalone application layout with styling, scripting, and branding
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Dashboard - PakMunshi Pro</title>
            <?php wp_head(); ?>
            <style>
                :root {
                    --bg-primary: #0b0f19;
                    --bg-secondary: #161e2e;
                    --text-primary: #f9fafb;
                    --text-secondary: #9ca3af;
                    --accent: #2563eb;
                    --accent-hover: #1d4ed8;
                    --border-color: #374151;
                }
                body {
                    margin: 0;
                    padding: 0;
                    background-color: var(--bg-primary);
                    color: var(--text-primary);
                    font-family: 'Outfit', 'Inter', sans-serif;
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                }
                .app-container {
                    display: flex;
                    flex: 1;
                    min-height: 100vh;
                }
                .sidebar {
                    width: 260px;
                    background-color: var(--bg-secondary);
                    border-right: 1px solid var(--border-color);
                    padding: 24px;
                    display: flex;
                    flex-direction: column;
                }
                .main-content {
                    flex: 1;
                    padding: 40px;
                    display: flex;
                    flex-direction: column;
                }
                .branding-footer {
                    margin-top: auto;
                    font-size: 12px;
                    color: var(--text-secondary);
                    text-align: center;
                    padding-top: 20px;
                    border-top: 1px solid var(--border-color);
                }
                h1 {
                    font-size: 24px;
                    margin-bottom: 8px;
                }
                .card {
                    background-color: var(--bg-secondary);
                    border: 1px solid var(--border-color);
                    border-radius: 8px;
                    padding: 24px;
                    margin-top: 24px;
                }
            </style>
        </head>
        <body>
            <div class="app-container">
                <aside class="sidebar">
                    <h2>PakMunshi Pro</h2>
                    <nav>
                        <!-- Nav items go here -->
                    </nav>
                    <div class="branding-footer">
                        <?php echo esc_html( PAKMUNSHI_BRANDING ); ?>
                    </div>
                </aside>
                <main class="main-content">
                    <header style="display:flex; justify-content:space-between; align-items:center;">
                        <h1>Welcome to PakMunshi Pro</h1>
                        <div>
                            <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" style="color: var(--text-secondary); text-decoration:none;">Logout</a>
                        </div>
                    </header>
                    <div class="card">
                        <h3>Multi-Tenant Engine Active (Phase 1)</h3>
                        <p>Tables registered successfully under Prefix: <code><?php global $wpdb; echo esc_html( $wpdb->prefix ); ?>pakmunshi_</code></p>
                        <p>All assets are dynamically routed to partition properties, units, rental tenants, and invoices by tenant account.</p>
                    </div>
                </main>
            </div>
            <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        exit;
    }
}
